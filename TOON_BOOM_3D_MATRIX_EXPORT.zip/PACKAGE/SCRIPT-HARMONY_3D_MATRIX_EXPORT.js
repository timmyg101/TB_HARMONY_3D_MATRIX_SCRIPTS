/******************************************************
 * Script Name:   3D_MATRIX_EXPORT.js
 * Author:        Tim Giovanni
 * Version:       1.4
 * Date:          August 2026
 * 
 ******************************************************/

function TG_3DMATRIXEXPORT()
{
  this.trace = function(m) { MessageLog.trace(m); }
  
  // 1. Gather nodes from SELECTION to get correct full paths
  var nodesToExport = [];
  
  var n = selection.numberOfNodesSelected();
  for (var i = 0; i < n; ++i) 
  {
     // CRITICAL: selectedNode(i) returns the FULL path (e.g., "Top/Camera_Peg/Camera_M")
     var selectedNode = selection.selectedNode(i); 
     var nodeType = node.type(selectedNode);
     var nodeName = node.getName(selectedNode);
     
     if (nodeType == "CAMERA" || nodeType == "PEG" || nodeType == "GROUP")
     {
        nodesToExport.push({
           path: selectedNode,
           type: nodeType,
           originalName: nodeName,
           exportName: nodeName
        });
     }
  }
  
  if (nodesToExport.length === 0)
  {
     MessageBox.information("No camera or pegs found. Please select them in the Node View and try again.");
     return;
  }
  
  // 2. Build Qt GUI
  var dialog = new QDialog();
  dialog.setWindowTitle("Export to Blender - Rename Objects");
  dialog.setMinimumSize(450, 300);
  
  var mainLayout = new QVBoxLayout();
  dialog.setLayout(mainLayout);
  
  var infoLabel = new QLabel("<b>Rename objects for Blender export:</b>");
  mainLayout.addWidget(infoLabel, 0, Qt.AlignLeft);
  
  var gridLayout = new QGridLayout();
  mainLayout.addLayout(gridLayout, 1);
  
  var lineEdits = [];
  for (var i = 0; i < nodesToExport.length; i++)
  {
     var typeLabel = new QLabel("[" + nodesToExport[i].type + "]");
     typeLabel.setStyleSheet("color: #4CAF50; font-weight: bold;");
     
     var origLabel = new QLabel(nodesToExport[i].originalName);
     origLabel.setStyleSheet("color: gray;");
     
     var lineEdit = new QLineEdit(nodesToExport[i].exportName);
     
     gridLayout.addWidget(typeLabel, i, 0, Qt.AlignLeft);
     gridLayout.addWidget(origLabel, i, 1, Qt.AlignLeft);
     gridLayout.addWidget(lineEdit, i, 2, Qt.AlignLeft);
     lineEdits.push(lineEdit);
  }
  
  var buttonLayout = new QHBoxLayout();
  var exportBtn = new QPushButton("Export JSON");
  var cancelBtn = new QPushButton("Cancel");
  buttonLayout.addStretch(1);
  buttonLayout.addWidget(exportBtn, 0, Qt.AlignRight);
  buttonLayout.addWidget(cancelBtn, 0, Qt.AlignRight);
  mainLayout.addLayout(buttonLayout, 0);
  
  var exportClicked = false;
  
  exportBtn.clicked.connect(function() {
     for (var i = 0; i < nodesToExport.length; i++) {
        nodesToExport[i].exportName = lineEdits[i].text;
     }
     exportClicked = true;
     dialog.accept();
  });
  
  cancelBtn.clicked.connect(function() {
     dialog.reject();
  });
  
  var result = dialog.exec();
  
  // 3. Perform Export
  if (result == 1 && exportClicked)
  {
     this.createSettingsObject = function()
     {
        return { type: "Settings",
                frameRate : scene.getFrameRate(), 
                unitsAspectRatioX : scene.unitsAspectRatioX(), 
                unitsAspectRatioY : scene.unitsAspectRatioY(), 
                unitsZ : scene.numberOfUnitsZ(),
                resolutionX : scene.currentResolutionX(),
                resolutionY: scene.currentResolutionY(),
                defaultResolutionFOV : scene.defaultResolutionFOV()
          };
     }

     this.createExportNodeObject = function(nodePath, objectType, exportName)
     {
        // CRITICAL FIX: Get the TRUE parent name from the full path
        var parentPath = node.parentNode(nodePath);
        var parentName = "Top";
        
        if (parentPath && parentPath !== "Top" && parentPath !== "") {
            parentName = node.getName(parentPath);
        }
        
        this.trace("Node: " + nodePath + " | Parent Path: " + parentPath + " | Parent Name: " + parentName);

        var obj = {
           type : objectType,
           name : exportName,
           parentNode : parentName, // This will now correctly say "Camera_Peg"
           position : [],
           scale : [],
           rotation : [],
           is3D : false
        };
      
        this.trace("Exporting " + objectType + ": " + exportName);
        var previousPosition, previousScale, previousRotation;
        var holdingPosition = false, holdingScale = false, holdingRotation = false;
       
        for(var i = 0; i < frame.numberOf(); ++i)
        {
           var frameNumber = 1 + i;
           
           // Use LOCAL matrix so the camera's position is relative to the peg
           var matrix = node.getMatrix(nodePath, frameNumber);
           
           var position = matrix.extractPosition();
           var scale = matrix.extractScale();
           var rotation = matrix.extractRotation();
  
           if (!i || position.isNotEqual(previousPosition))
           {
               if (holdingPosition) obj.position.push([i-1, previousPosition.x, previousPosition.y, previousPosition.z]);  
               obj.position.push([i, position.x, position.y, position.z]);
               holdingPosition = false;
           } else { holdingPosition = true; }
  
           if (!i || scale.isNotEqual(previousScale))
           {
               if (holdingScale) obj.scale.push([i-1, previousScale.x, previousScale.y, previousScale.z]);  
               obj.scale.push([i, scale.x, scale.y, scale.z]);       
               holdingScale = false;
           } else { holdingScale = true; }
  
           if (!i || rotation.isNotEqual(previousRotation))
           {
               if (holdingRotation) obj.rotation.push([i-1, previousRotation.x, previousRotation.y, previousRotation.z]);  
               obj.rotation.push([i, rotation.x, rotation.y, rotation.z]);       
               holdingRotation = false;
               
               if (rotation.x < -0.00001 || rotation.x > 0.00001 || rotation.y < -0.00001 || rotation.y > 0.00001) { 
                   obj.is3D = true;
               }
           } else { holdingRotation = true; }
  
           previousPosition = position; previousScale = scale; previousRotation = rotation;
        }
       return obj;
     }
     
     var exportData = [this.createSettingsObject()];
     
     for (var i = 0; i < nodesToExport.length; i++)
     {
        exportData.push(this.createExportNodeObject(nodesToExport[i].path, nodesToExport[i].type, nodesToExport[i].exportName));
     }
     
     var filename = FileDialog.getSaveFileName("*.json", "Please select the export filename");
     if (!filename) { this.trace("Aborted."); return; }
     
     var file = new File(filename);
     file.open(FileAccess.WriteOnly);
     file.write(JSON.stringify(exportData, null, 2)); 
     file.close();
     
     MessageBox.information("Export Complete!\n\nSaved to:\n" + filename);
  }
}