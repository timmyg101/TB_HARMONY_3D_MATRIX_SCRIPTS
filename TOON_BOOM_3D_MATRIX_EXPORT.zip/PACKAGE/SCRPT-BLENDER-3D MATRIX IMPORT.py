bl_info = {
    "name": "Import Harmony 3D Matrix Script",
    "author": "Tim Giovanni - Copyright8.26.2026",
    "version": (3, 10),
    "blender": (3, 0, 0),
    "location": "File > Import",
    "description": "Imports Toon Boom Harmony 3D Matrix JSON Files from TG 3D MATRIX EXPORT",
    "category": "Import-Export",
}

import bpy
import json
import math
from bpy_extras.io_utils import ImportHelper
from bpy.props import StringProperty
from bpy.types import Operator

class ImportHarmonyScene(Operator, ImportHelper):
    bl_idname = "import_scene.harmony_3d_matrix"
    bl_label = "Import Harmony 3D Matrix"
    bl_options = {'PRESET', 'UNDO'}
    filename_ext = ".json"
    filter_glob: StringProperty(default="*.json;*.jsonx", options={'HIDDEN'}, maxlen=255)

    def execute(self, context):
        import_harmony_scene(self.filepath, context)
        return {'FINISHED'}

def fov_to_lens(fov_degrees, sensor_width=36.0):
    """Convert FOV (degrees) to lens focal length (mm)"""
    fov_rad = math.radians(fov_degrees)
    return sensor_width / (2 * math.tan(fov_rad / 2))

def calculate_correct_fov(harmony_fov, harmony_aspect_x, harmony_aspect_y, render_x, render_y):
    """
    Convert Harmony's FOV (4:3 field) to Blender's FOV (16:9 render)
    
    Based on empirical testing: 41.112° -> 67.38° (ratio: 1.639)
    """
    harmony_ratio = harmony_aspect_x / harmony_aspect_y  # 4/3 = 1.333
    render_ratio = render_x / render_y  # 1920/1080 = 1.778
    
    # Correct multiplier: (render_ratio / harmony_ratio) * sqrt(3/2)
    # = 1.333 * 1.225 = 1.633 (close to empirical 1.639)
    multiplier = (render_ratio / harmony_ratio) * math.sqrt(1.5)
    
    corrected_fov = harmony_fov * multiplier
    
    return corrected_fov

def import_harmony_scene(json_filepath, context):
    with open(json_filepath, 'r') as f:
        data = json.load(f)

    settings = data[0]
    units_z = float(settings.get("unitsZ", 100))
    aspect_x = float(settings.get("unitsAspectRatioX", 4.0))
    aspect_y = float(settings.get("unitsAspectRatioY", 3.0))
    res_x = int(settings.get("resolutionX", 1920))
    res_y = int(settings.get("resolutionY", 1080))
    default_fov = float(settings.get("defaultResolutionFOV", 41.11209043916693))

    fromOglZ = units_z * 0.5 * aspect_y / aspect_x
    resolution_aspect_ratio = res_x / res_y

    context.scene.render.resolution_x = res_x
    context.scene.render.resolution_y = res_y
    context.scene.render.fps = int(settings.get("frameRate", 24))

    max_frame = 1
    imported_objects = {}
    top_scene_obj = None

    # Pass 1: Create all objects
    for obj_data in data[1:]:
        obj_type = obj_data.get("type")
        obj_name = obj_data.get("name", "Object")
        
        print(f"Creating: {obj_name} ({obj_type})")
        
        if obj_type == "CAMERA":
            cam_obj = create_camera(obj_data, context, fromOglZ, resolution_aspect_ratio, default_fov, aspect_x, aspect_y, res_x, res_y)
            imported_objects[obj_name] = cam_obj
            imported_objects[obj_name + "_Rig"] = cam_obj.parent
        elif obj_type == "PEG":
            is_3d = obj_data.get("is3D", False)
            has_rotation = any(abs(kf[2]) > 0.00001 for kf in obj_data.get("rotation", [[0,0,0,0]]))
            
            if is_3d and has_rotation and "camera" in obj_name.lower():
                cam_obj = create_camera_from_peg(obj_data, context, fromOglZ, resolution_aspect_ratio, default_fov, aspect_x, aspect_y, res_x, res_y)
                imported_objects[obj_name] = cam_obj
                imported_objects[obj_name + "_Rig"] = cam_obj.parent
                print(f"  ✓ Created camera rig from peg: {obj_name}")
            else:
                peg_obj = create_peg(obj_data, context, fromOglZ)
                imported_objects[obj_name] = peg_obj
                
                if obj_name == "TOP_SCENE":
                    top_scene_obj = peg_obj
                    print(f"  ✓ Found TOP_SCENE root")
        
        for kf in obj_data.get("position", []):
            frame_num = int(kf[0] + 1)
            if frame_num > max_frame:
                max_frame = frame_num

    # Pass 2: Apply TOP_SCENE hierarchy
    if top_scene_obj:
        print("\n🎯 Applying TOP_SCENE hierarchy...")
        for obj_name, obj in imported_objects.items():
            if obj_name != "TOP_SCENE":
                if hasattr(obj, 'type') and obj.type == 'CAMERA' and obj.parent:
                    obj.parent.parent = top_scene_obj
                    print(f"  ✓ Parented {obj_name}_Rig to TOP_SCENE")
                else:
                    obj.parent = top_scene_obj
                    print(f"  ✓ Parented {obj_name} to TOP_SCENE")
    else:
        print("\n️ No TOP_SCENE found")

    context.scene.frame_start = 1
    context.scene.frame_end = max_frame
    print(f"\n✅ Import complete - Timeline: 1-{max_frame}")

def create_camera_from_peg(peg_data, context, fromOglZ, res_ratio, default_fov, aspect_x, aspect_y, res_x, res_y):
    """Create a camera rig from a peg with corrected FOV"""
    bpy.ops.object.empty_add(type='PLAIN_AXES', location=(0,0,0))
    rig = context.active_object
    rig.name = peg_data.get("name", "Camera") + "_Rig"
    
    bpy.ops.object.camera_add()
    cam_obj = context.active_object
    cam_obj.name = peg_data.get("name", "Camera").replace("-P", "_M") + "_Cam"
    cam = cam_obj.data
    
    # Set sensor to match Harmony's units aspect ratio (4:3)
    cam.sensor_fit = 'HORIZONTAL'
    cam.sensor_width = 36.0
    cam.sensor_height = 36.0 * (aspect_y / aspect_x)  # 27mm for 4:3
    
    # FIX: Calculate correct FOV for 16:9 render
    corrected_fov = calculate_correct_fov(default_fov, aspect_x, aspect_y, res_x, res_y)
    
    # Convert FOV to lens
    initial_lens = fov_to_lens(corrected_fov, 36.0)
    cam.lens = initial_lens
    
    print(f"Harmony FOV: {default_fov:.3f}° -> Corrected FOV: {corrected_fov:.3f}° -> Lens: {initial_lens:.1f}mm")
    
    cam_obj.parent = rig
    cam_obj.location = (0, 0, 0)
    cam_obj.rotation_euler = (math.radians(90), 0, 0)
    cam_obj.rotation_mode = 'XYZ'
    
    # Position Keyframes
    for kf in peg_data.get("position", []):
        frame_idx = int(kf[0] + 1)
        x, y, z = kf[1], kf[2], kf[3]
        rig.location = (x * fromOglZ, -z * fromOglZ, y * fromOglZ)
        rig.keyframe_insert(data_path="location", frame=frame_idx)

    # Rotation Keyframes
    for kf in peg_data.get("rotation", []):
        frame_idx = int(kf[0] + 1)
        rx, ry, rz = kf[1], kf[2], kf[3]
        rig.rotation_euler = (math.radians(rx), math.radians(-rz), math.radians(ry))
        rig.keyframe_insert(data_path="rotation_euler", frame=frame_idx)

    # Scale Keyframes
    for kf in peg_data.get("scale", [[0, 1.0, 1.0, 1.0]]):
        frame_idx = int(kf[0] + 1)
        sx, sy, sz = kf[1], kf[2], kf[3]
        rig.scale = (sx, sy, sz)
        rig.keyframe_insert(data_path="scale", frame=frame_idx)
        
        if sy != 0:
            new_fov = corrected_fov / sy
            new_lens = fov_to_lens(new_fov, 36.0)
            cam.lens = new_lens
            cam.keyframe_insert(data_path="lens", frame=frame_idx)
    
    return cam_obj

def create_camera(cam_data, context, fromOglZ, res_ratio, default_fov, aspect_x, aspect_y, res_x, res_y):
    """Create a regular camera with corrected FOV"""
    bpy.ops.object.empty_add(type='PLAIN_AXES', location=(0,0,0))
    rig = context.active_object
    rig.name = cam_data.get("name", "Harmony_Camera") + "_Rig"
    
    bpy.ops.object.camera_add()
    cam_obj = context.active_object
    cam_obj.name = cam_data.get("name", "Harmony_Camera")
    cam = cam_obj.data
    
    # Set sensor to match Harmony's units aspect ratio (4:3)
    cam.sensor_fit = 'HORIZONTAL'
    cam.sensor_width = 36.0
    cam.sensor_height = 36.0 * (aspect_y / aspect_x)
    
    # FIX: Calculate correct FOV for 16:9 render
    corrected_fov = calculate_correct_fov(default_fov, aspect_x, aspect_y, res_x, res_y)
    
    initial_lens = fov_to_lens(corrected_fov, 36.0)
    cam.lens = initial_lens
    
    print(f"Harmony FOV: {default_fov:.3f}° -> Corrected FOV: {corrected_fov:.3f}° -> Lens: {initial_lens:.1f}mm")
    
    cam_obj.parent = rig
    cam_obj.location = (0, 0, 0)
    cam_obj.rotation_euler = (math.radians(90), 0, 0)
    cam_obj.rotation_mode = 'XYZ'
    
    for kf in cam_data.get("position", []):
        frame_idx = int(kf[0] + 1)
        x, y, z = kf[1], kf[2], kf[3]
        rig.location = (x * fromOglZ, -z * fromOglZ, y * fromOglZ)
        rig.keyframe_insert(data_path="location", frame=frame_idx)

    for kf in cam_data.get("rotation", []):
        frame_idx = int(kf[0] + 1)
        rx, ry, rz = kf[1], kf[2], kf[3]
        rig.rotation_euler = (math.radians(rx), math.radians(-rz), math.radians(ry))
        rig.keyframe_insert(data_path="rotation_euler", frame=frame_idx)

    for kf in cam_data.get("scale", [[0, 1.0, 1.0, 1.0]]):
        frame_idx = int(kf[0] + 1)
        scale = kf[1]
        if scale != 0:
            new_fov = corrected_fov / scale
            new_lens = fov_to_lens(new_fov, 36.0)
            cam.lens = new_lens
        cam.keyframe_insert(data_path="lens", frame=frame_idx)
    
    return cam_obj

def create_peg(peg_data, context, fromOglZ):
    """Create a regular peg empty"""
    bpy.ops.object.empty_add(type='PLAIN_AXES', location=(0,0,0))
    empty_obj = context.active_object
    empty_obj.name = peg_data.get("name", "Peg")
    empty_obj.empty_display_size = 0.5
    
    for kf in peg_data.get("position", []):
        frame_idx = int(kf[0] + 1)
        x, y, z = kf[1], kf[2], kf[3]
        empty_obj.location = (x * fromOglZ, -z * fromOglZ, y * fromOglZ)
        empty_obj.keyframe_insert(data_path="location", frame=frame_idx)

    for kf in peg_data.get("rotation", []):
        frame_idx = int(kf[0] + 1)
        rx, ry, rz = kf[1], kf[2], kf[3]
        empty_obj.rotation_euler = (math.radians(rx), math.radians(-rz), math.radians(ry))
        empty_obj.keyframe_insert(data_path="rotation_euler", frame=frame_idx)

    for kf in peg_data.get("scale", [[0, 1.0, 1.0, 1.0]]):
        frame_idx = int(kf[0] + 1)
        sx, sy, sz = kf[1], kf[2], kf[3]
        empty_obj.scale = (sx, sy, sz)
        empty_obj.keyframe_insert(data_path="scale", frame=frame_idx)
    
    return empty_obj

def menu_func_import(self, context):
    self.layout.operator(ImportHarmonyScene.bl_idname, text="Harmony 3D Matrix (.json)")

def register():
    bpy.utils.register_class(ImportHarmonyScene)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)

def unregister():
    bpy.utils.unregister_class(ImportHarmonyScene)
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)

if __name__ == "__main__":
    register()
    bpy.ops.import_scene.harmony_3d_matrix('INVOKE_DEFAULT')